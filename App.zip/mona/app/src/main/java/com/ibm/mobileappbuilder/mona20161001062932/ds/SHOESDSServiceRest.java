
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface SHOESDSServiceRest{

	@GET("/app/57ef584c57acb003000656a4/r/sHOESDS")
	void querySHOESDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<SHOESDSItem>> cb);

	@GET("/app/57ef584c57acb003000656a4/r/sHOESDS/{id}")
	void getSHOESDSItemById(@Path("id") String id, Callback<SHOESDSItem> cb);

	@DELETE("/app/57ef584c57acb003000656a4/r/sHOESDS/{id}")
  void deleteSHOESDSItemById(@Path("id") String id, Callback<SHOESDSItem> cb);

  @POST("/app/57ef584c57acb003000656a4/r/sHOESDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<SHOESDSItem>> cb);

  @POST("/app/57ef584c57acb003000656a4/r/sHOESDS")
  void createSHOESDSItem(@Body SHOESDSItem item, Callback<SHOESDSItem> cb);

  @PUT("/app/57ef584c57acb003000656a4/r/sHOESDS/{id}")
  void updateSHOESDSItem(@Path("id") String id, @Body SHOESDSItem item, Callback<SHOESDSItem> cb);

  @GET("/app/57ef584c57acb003000656a4/r/sHOESDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef584c57acb003000656a4/r/sHOESDS")
    void createSHOESDSItem(
        @Part("data") SHOESDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SHOESDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef584c57acb003000656a4/r/sHOESDS/{id}")
    void updateSHOESDSItem(
        @Path("id") String id,
        @Part("data") SHOESDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SHOESDSItem> cb);
}

