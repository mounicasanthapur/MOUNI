
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface JACKETSDSServiceRest{

	@GET("/app/57ef584c57acb003000656a4/r/jACKETSDS")
	void queryJACKETSDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<JACKETSDSItem>> cb);

	@GET("/app/57ef584c57acb003000656a4/r/jACKETSDS/{id}")
	void getJACKETSDSItemById(@Path("id") String id, Callback<JACKETSDSItem> cb);

	@DELETE("/app/57ef584c57acb003000656a4/r/jACKETSDS/{id}")
  void deleteJACKETSDSItemById(@Path("id") String id, Callback<JACKETSDSItem> cb);

  @POST("/app/57ef584c57acb003000656a4/r/jACKETSDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<JACKETSDSItem>> cb);

  @POST("/app/57ef584c57acb003000656a4/r/jACKETSDS")
  void createJACKETSDSItem(@Body JACKETSDSItem item, Callback<JACKETSDSItem> cb);

  @PUT("/app/57ef584c57acb003000656a4/r/jACKETSDS/{id}")
  void updateJACKETSDSItem(@Path("id") String id, @Body JACKETSDSItem item, Callback<JACKETSDSItem> cb);

  @GET("/app/57ef584c57acb003000656a4/r/jACKETSDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef584c57acb003000656a4/r/jACKETSDS")
    void createJACKETSDSItem(
        @Part("data") JACKETSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JACKETSDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef584c57acb003000656a4/r/jACKETSDS/{id}")
    void updateJACKETSDSItem(
        @Path("id") String id,
        @Part("data") JACKETSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JACKETSDSItem> cb);
}

