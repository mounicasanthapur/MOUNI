
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.mona20161001062932.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "SHIRTSDSService" REST Service implementation
 */
public class SHIRTSDSService extends RestService<SHIRTSDSServiceRest>{

    public static SHIRTSDSService getInstance(){
          return new SHIRTSDSService();
    }

    private SHIRTSDSService() {
        super(SHIRTSDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "A7TcGyte";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef584c57acb003000656a4",
                path,
                "apikey=A7TcGyte");
    }

}

