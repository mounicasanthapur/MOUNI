
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface KURTHISDSServiceRest{

	@GET("/app/57ef584c57acb003000656a4/r/kURTHISDS")
	void queryKURTHISDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<KURTHISDSItem>> cb);

	@GET("/app/57ef584c57acb003000656a4/r/kURTHISDS/{id}")
	void getKURTHISDSItemById(@Path("id") String id, Callback<KURTHISDSItem> cb);

	@DELETE("/app/57ef584c57acb003000656a4/r/kURTHISDS/{id}")
  void deleteKURTHISDSItemById(@Path("id") String id, Callback<KURTHISDSItem> cb);

  @POST("/app/57ef584c57acb003000656a4/r/kURTHISDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<KURTHISDSItem>> cb);

  @POST("/app/57ef584c57acb003000656a4/r/kURTHISDS")
  void createKURTHISDSItem(@Body KURTHISDSItem item, Callback<KURTHISDSItem> cb);

  @PUT("/app/57ef584c57acb003000656a4/r/kURTHISDS/{id}")
  void updateKURTHISDSItem(@Path("id") String id, @Body KURTHISDSItem item, Callback<KURTHISDSItem> cb);

  @GET("/app/57ef584c57acb003000656a4/r/kURTHISDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef584c57acb003000656a4/r/kURTHISDS")
    void createKURTHISDSItem(
        @Part("data") KURTHISDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<KURTHISDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef584c57acb003000656a4/r/kURTHISDS/{id}")
    void updateKURTHISDSItem(
        @Path("id") String id,
        @Part("data") KURTHISDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<KURTHISDSItem> cb);
}

