
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class JACKETSDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("bRANDNAME") public String bRANDNAME;
    @SerializedName("pRICE") public String pRICE;
    @SerializedName("picture") public String picture;
    @SerializedName("rATING") public String rATING;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(bRANDNAME);
        dest.writeString(pRICE);
        dest.writeString(picture);
        dest.writeString(rATING);
        dest.writeString(id);
    }

    public static final Creator<JACKETSDSItem> CREATOR = new Creator<JACKETSDSItem>() {
        @Override
        public JACKETSDSItem createFromParcel(Parcel in) {
            JACKETSDSItem item = new JACKETSDSItem();

            item.bRANDNAME = in.readString();
            item.pRICE = in.readString();
            item.picture = in.readString();
            item.rATING = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public JACKETSDSItem[] newArray(int size) {
            return new JACKETSDSItem[size];
        }
    };

}


