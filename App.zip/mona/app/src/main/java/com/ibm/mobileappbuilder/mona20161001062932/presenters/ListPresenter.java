
package com.ibm.mobileappbuilder.mona20161001062932.presenters;

import com.ibm.mobileappbuilder.mona20161001062932.R;
import com.ibm.mobileappbuilder.mona20161001062932.ds.JACKETSDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class ListPresenter extends BasePresenter implements ListCrudPresenter<JACKETSDSItem>,
      Datasource.Listener<JACKETSDSItem>{

    private final CrudDatasource<JACKETSDSItem> crudDatasource;
    private final CrudListView<JACKETSDSItem> view;

    public ListPresenter(CrudDatasource<JACKETSDSItem> crudDatasource,
                                         CrudListView<JACKETSDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(JACKETSDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<JACKETSDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(JACKETSDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(JACKETSDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(JACKETSDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

