
package com.ibm.mobileappbuilder.mona20161001062932.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface JEANSDSServiceRest{

	@GET("/app/57ef584c57acb003000656a4/r/jEANSDS")
	void queryJEANSDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<JEANSDSItem>> cb);

	@GET("/app/57ef584c57acb003000656a4/r/jEANSDS/{id}")
	void getJEANSDSItemById(@Path("id") String id, Callback<JEANSDSItem> cb);

	@DELETE("/app/57ef584c57acb003000656a4/r/jEANSDS/{id}")
  void deleteJEANSDSItemById(@Path("id") String id, Callback<JEANSDSItem> cb);

  @POST("/app/57ef584c57acb003000656a4/r/jEANSDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<JEANSDSItem>> cb);

  @POST("/app/57ef584c57acb003000656a4/r/jEANSDS")
  void createJEANSDSItem(@Body JEANSDSItem item, Callback<JEANSDSItem> cb);

  @PUT("/app/57ef584c57acb003000656a4/r/jEANSDS/{id}")
  void updateJEANSDSItem(@Path("id") String id, @Body JEANSDSItem item, Callback<JEANSDSItem> cb);

  @GET("/app/57ef584c57acb003000656a4/r/jEANSDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef584c57acb003000656a4/r/jEANSDS")
    void createJEANSDSItem(
        @Part("data") JEANSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JEANSDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef584c57acb003000656a4/r/jEANSDS/{id}")
    void updateJEANSDSItem(
        @Path("id") String id,
        @Part("data") JEANSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<JEANSDSItem> cb);
}

