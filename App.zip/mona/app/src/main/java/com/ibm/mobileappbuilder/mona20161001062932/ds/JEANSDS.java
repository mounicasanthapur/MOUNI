

package com.ibm.mobileappbuilder.mona20161001062932.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "JEANSDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class JEANSDS extends AppNowDatasource<JEANSDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private JEANSDSService service;

    public static JEANSDS getInstance(SearchOptions searchOptions){
        return new JEANSDS(searchOptions);
    }

    private JEANSDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = JEANSDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<JEANSDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<JEANSDSItem>>() {
                @Override
                public void onSuccess(List<JEANSDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new JEANSDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getJEANSDSItemById(id, new Callback<JEANSDSItem>() {
                @Override
                public void success(JEANSDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<JEANSDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<JEANSDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryJEANSDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<JEANSDSItem>>() {
            @Override
            public void success(List<JEANSDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"bRAND", "pRICE", "rATINGS"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(JEANSDSItem item, Listener<JEANSDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().createJEANSDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createJEANSDSItem(item, callbackFor(listener));
        
    }

    private Callback<JEANSDSItem> callbackFor(final Listener<JEANSDSItem> listener) {
      return new Callback<JEANSDSItem>() {
          @Override
          public void success(JEANSDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(JEANSDSItem item, Listener<JEANSDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().updateJEANSDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateJEANSDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(JEANSDSItem item, final Listener<JEANSDSItem> listener) {
                service.getServiceProxy().deleteJEANSDSItemById(item.getIdentifiableId(), new Callback<JEANSDSItem>() {
            @Override
            public void success(JEANSDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<JEANSDSItem> items, final Listener<JEANSDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<JEANSDSItem>>() {
            @Override
            public void success(List<JEANSDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<JEANSDSItem> items){
        List<String> ids = new ArrayList<>();
        for(JEANSDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

